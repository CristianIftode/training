import './App.css';
import { createContext, useState } from 'react';
import Counter from './Counter';
// 1. useState
// 2. useContext
// 3. useEffect , useLayoutEffect
// 4. useRef
// 5. useMemo
// 6. useCallBack

const ThemeContext = createContext();


function App() {
 
  const [theme, setTheme] = useState('light');

  const toggleTheme = () =>{
    setTheme((prevTheme) => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  return(
    <>
        <div className={`App ${theme}`}>
          <h1>Счётчик с темами</h1>
          <Counter theme={theme} />
          <button onClick={toggleTheme}>Сменить тему</button>
        </div>
    </>
  );
}






export default App;
export {ThemeContext}