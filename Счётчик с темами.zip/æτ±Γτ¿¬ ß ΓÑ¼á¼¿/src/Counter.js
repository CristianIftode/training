import { useContext, useState } from "react";
import { ThemeContext } from './App'

function Counter({theme}){

    const [count, setCount] = useState(0);

    return(
        <div className={`counter ${theme}`}>
            <p>Текущее значение: </p>
            <span>{count}</span>
            <button onClick={()=>setCount(count+1)}>Увеличить</button>
            <button onClick={()=>setCount(count-1)}>Уменьшить</button>
        </div>
    )

}


export default Counter;