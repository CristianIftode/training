import { useState } from "react"



function Notes({theme}){

    const [note, setNote] = useState('');
    const [notes, setNotes] = useState([]);

    const AddNote = () =>{
        if(note !== ""){
            setNotes([...notes, note.trim()]);
            setNote('');
        }
    }

    const DeleteNote = (index) =>{
        setNotes(notes.filter((_, i) => i !== index));
    }

    return(

    <div className={`notes ${theme}`}>
    
    <input 
        type="text"
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Напишите заметку"/>

    <button onClick={AddNote}>Сохранить заметку</button>

    <ul>
        {notes.map((note, index)=>(
            <li key={index}><span>{note}</span>
            <button onClick={() => DeleteNote(index)}> Удалить </button>
            </li>
        ))}
    </ul>

    </div>
    )
}

export default Notes;