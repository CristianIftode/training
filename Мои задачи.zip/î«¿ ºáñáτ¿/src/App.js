import './App.css';
import { useState } from 'react';
import Notes from './Notes';
// 1. useState
// 2. useContext
// 3. useEffect , useLayoutEffect
// 4. useRef
// 5. useMemo
// 6. useCallBack


function App() {
 
  const [theme, setTheme] = useState('light');

  const toggleTheme = () =>{
    setTheme((prevTheme) => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  return(
    <>
        <div className={`App ${theme}`}>
          <h1>Мои заметки</h1>
          <Notes theme={theme}/>
          <button onClick={toggleTheme}>Сменить тему</button>
        </div>
    </>
  );
}






export default App;